# Trabajo-Final-LHG
Pagina web

Este nuevo repositorio es la entrega del trabajo final, ya que he estado terminado el trabajo con mi compañera Victoria Fuertes y hemos tenido algunos problemas en la hora de la entrega final. Primero hemos entregado un link con el trabajo sin terminar y después hemos corregido los fallos y hemos creado un nuevo repositorio con un nuevo link, porque no conseguíamos actualizar el anterior.

Este es el link del trabajo final: [Trabajo Final Lucía](https://luciahdezg.github.io/Trabajo-Final-LHG/metodologia.html)
